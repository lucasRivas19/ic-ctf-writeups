msg = b'This is just a test message and can totally be ignored.'
encrypted_msg = bytes.fromhex("d71f4a2fd1f9362c21ad33c7735251d0a671185a1b90ecba27713d350611eb8179ec67ca7052aa8bad60466b83041e6c02dbfee738c2a3")
encrypted_flag = bytes.fromhex("c234661fa5d63e627bef28823d052e95f65d59491580edfa1927364a5017be9445fa39986859a3")


# Ya que se tiene el texto sin cifrar y el texto cifrado, se puede hacer el XOR para obtener el keystream
keystream = bytes([a ^ b for a, b in zip(msg, encrypted_msg)])

# Y ahopra que ya tenemos el keystream, se hace el XOR entre el keystream y el texto cifrado para obtener el texto sin cifrar
flag = bytes([a ^ b for a, b in zip(keystream, encrypted_flag)])
print(flag)

#FLAG: ACECTF{n07h1n6_15_53cur3_1n_7h15_w0rld}