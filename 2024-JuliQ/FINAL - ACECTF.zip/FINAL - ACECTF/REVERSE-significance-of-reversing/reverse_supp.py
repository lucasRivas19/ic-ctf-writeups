# Read the file
with open("Reverseme.png", "rb") as f:
    data = f.read()

# Reverse the data
reversed_data = data[::-1]

# Write the reversed data to a new file
with open("fixed_file", "wb") as f:
    f.write(reversed_data)